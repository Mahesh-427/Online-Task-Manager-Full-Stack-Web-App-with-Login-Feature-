
# ✅ Task Manager Full-Stack Project (with Login)

## 🧱 Tech Stack
- Frontend: React.js (with Login functionality)
- Backend: Node.js + Express + CORS
- Database: Python + SQLite

## ⚡ How To Run

### 1️⃣ Backend
cd backend
npm install express cors
node server.js

### 2️⃣ Database
cd database
python db.py

### 3️⃣ Frontend
npx create-react-app frontend
cd frontend
npm install
npm start

✅ Open http://localhost:3000 in your browser.

## 🔧 Features
- Login Page (admin / 1234)
- Add Task
- List Tasks
- Tasks are stored in database

💡 Pro Tip: Use separate terminals for backend, database, and frontend.
