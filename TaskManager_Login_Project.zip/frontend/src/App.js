
import React, { useState, useEffect } from 'react';
import Login from './Login';
import './App.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const response = await fetch('http://localhost:5000/tasks');
    const data = await response.json();
    setTasks(data);
  };

  useEffect(() => {
    if (isLoggedIn) fetchTasks();
  }, [isLoggedIn]);

  const addTask = async () => {
    await fetch('http://localhost:5000/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task })
    });
    setTask('');
    fetchTasks();
  };

  if (!isLoggedIn) {
    return <Login onLogin={setIsLoggedIn} />;
  }

  return (
    <div className="App">
      <h1>Task Manager</h1>
      <input value={task} onChange={(e) => setTask(e.target.value)} placeholder="Enter Task" />
      <button onClick={addTask}>Add Task</button>
      <ul>
        {tasks.map((t, i) => <li key={i}>{t.text}</li>)}
      </ul>
    </div>
  );
}

export default App;
