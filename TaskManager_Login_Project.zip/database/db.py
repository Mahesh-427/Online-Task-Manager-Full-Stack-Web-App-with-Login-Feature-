
import sqlite3
import sys

task_text = sys.argv[1]

conn = sqlite3.connect('tasks.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, text TEXT, done BOOLEAN)''')
c.execute('INSERT INTO tasks (text, done) VALUES (?, ?)''', (task_text, False))
conn.commit()

print("Task Added Successfully")
